<?php

namespace App\Http\Controllers\MK;

use App\Http\Controllers\Controller;
use App\Services\MediaKernelsClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class NewsController extends Controller
{
    protected $mkClient;

    public function __construct(MediaKernelsClient $mkClient)
    {
        $this->mkClient = $mkClient;
    }

    private function getAllProjects(): array
    {
        $user = Auth::user();
        $assignedProjectIds = $user->assignedProjectIds();

        $rawProjects = $this->mkClient->listProjects(0, 100);
        $allProjects = array_values($rawProjects);

        $userProjects = array_filter($allProjects, function ($project) use ($assignedProjectIds) {
            return in_array($project['id'] ?? null, $assignedProjectIds);
        });

        return array_values($userProjects);
    }

    // ════════════════════════════════════════════════════════════════
    // ✅ FIX UTAMA: Helper extract array dari MK API response
    // MK API kadang return: raw array [], {data:[]}, atau {success,data}
    // ════════════════════════════════════════════════════════════════
    private function extractArray($response): array
    {
        if (!$response) return [];

        // Plain indexed array (most MK endpoints return raw [])
        if (is_array($response) && (empty($response) || isset($response[0]))) {
            return $response;
        }

        // {data: [...]} format
        if (isset($response['data']) && is_array($response['data'])) {
            return $response['data'];
        }

        // {success: true, data: [...]} format
        if (isset($response['success']) && isset($response['data'])) {
            return is_array($response['data']) ? $response['data'] : [];
        }

        if (is_array($response)) return $response;

        return [];
    }

    public function recentTopicsPage(Request $request)
    {
        try {
            $level = $request->query('level', 'internasional');
            $size = (int) $request->query('size', 10);

            Log::info('=== RECENT TOPICS PAGE (HYBRID) ===', [
                'level' => $level,
                'size' => $size,
            ]);

            if (!in_array($level, ['internasional', 'nasional', 'regional_apac'])) {
                $level = 'internasional';
            }

            $response = $this->mkClient->recentTopicsHybrid($level, $size);

            $issues = $response['daftar_isu'] ?? [];
            $apiVersion = $response['api_version'] ?? 'unknown';
            $status = $response['status'] ?? 'unknown';

            Log::info('=== FINAL DATA ===', [
                'api_version' => $apiVersion,
                'status' => $status,
                'issues_count' => count($issues),
                'first_issue' => count($issues) > 0 ? $issues[0]['judul'] : 'no issues',
            ]);

            return view('mk.news.recent-topics', [
                'level' => $level,
                'size' => $size,
                'issues' => $issues,
                'apiVersion' => $apiVersion,
                'status' => $status,
            ]);

        } catch (\Exception $e) {
            Log::error('Page Error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return view('mk.news.recent-topics', [
                'level' => $request->query('level', 'internasional'),
                'size' => 10,
                'issues' => [],
                'apiVersion' => 'error',
                'status' => 'error',
                'error' => 'Failed to load topics',
            ]);
        }
    }

    public function recentTopicsApi(Request $request)
    {
        try {
            $level = $request->query('level', 'internasional');
            $size = (int) $request->query('size', 10);

            if (!in_array($level, ['internasional', 'nasional', 'regional_apac'])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid level parameter',
                ], 400);
            }

            $response = $this->mkClient->recentTopicsHybrid($level, $size);

            return response()->json([
                'success' => $response['status'] === 'success',
                'level' => $level,
                'api_version' => $response['api_version'] ?? 'unknown',
                'data' => $response['daftar_isu'] ?? [],
            ]);

        } catch (\Exception $e) {
            Log::error('API Error', ['error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch topics',
                'data' => [],
            ], 500);
        }
    }

    public function newsWordCloudPage(Request $request)
    {
        try {
            $projects  = $this->getAllProjects();
            $projectId = $request->query('project_id', session('selected_project_id'));
            
            if (!$projectId && count($projects) > 0) {
                $projectId = $projects[0]['id'] ?? null;
            }

            if (!$projectId) {
                Log::warning('News Word Cloud: No project selected');
                return redirect()->route('mk.dashboard')
                    ->with('error', 'Please select a project first');
            }

            session(['selected_project_id' => $projectId]);

            $endDate = $request->query('end_date', now()->format('Y-m-d'));
            $startDate = $request->query('start_date', now()->subDays(29)->format('Y-m-d'));

            return view('mk.news.word-cloud', [
                'projectId' => $projectId,
                'startDate' => $startDate,
                'endDate' => $endDate,
                'projects' => $projects,
            ]);

        } catch (\Exception $e) {
            Log::error('News Word Cloud Page Error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return redirect()->route('mk.dashboard')
                ->with('error', 'Failed to load News Word Cloud page');
        }
    }

    /**
     * API: Get News Word Cloud Data (ENHANCED VERSION)
     */
public function newsWordCloudData(Request $request)
{
    try {
        $projectId = $request->query('project_id');
        $startDate = $request->query('start_date');
        $endDate   = $request->query('end_date');
        $sentiment = $request->query('sentiment', '2');

        if (!$projectId) {
            return response()->json(['success' => false, 'error' => 'Project ID is required'], 400);
        }

        Log::info('🔍 News Word Cloud - Fetching from articles/doc', [
            'project_id' => $projectId,
            'start_date' => $startDate,
            'end_date'   => $endDate,
            'sentiment'  => $sentiment,
        ]);

        $phrases = [];

        // ── 1. PRIMARY: WordCloud API dulu ───────────────────────────
        try {
            $wordCloudData = $this->mkClient->wordCloud(
                $projectId, $startDate, 0, $endDate, 23, $sentiment
            );

            $wcPhrases = $wordCloudData['data']['phrases']
                      ?? $wordCloudData['phrases']
                      ?? [];

            foreach ($wcPhrases as $word => $count) {
                $phrases[$word] = ($phrases[$word] ?? 0) + (int) $count;
            }

            Log::info('✅ WordCloud API', ['count' => count($wcPhrases)]);
        } catch (\Exception $e) {
            Log::warning('⚠️ WordCloud API failed', ['error' => $e->getMessage()]);
        }

        // ── 2. PRIMARY: Ambil articles (doc = online news) ───────────
        // Ini sumber utama DroneEmprit, ambil banyak artikel lalu
        // text-mine title + content untuk dapat semua kata
        try {
            $articles = $this->mkClient->articles(
                $projectId,
                'doc',      // media type: doc = online news
                $startDate,
                $endDate,
                0,          // sentiment_id (0=all)
                23,         // end hour
                0,          // offset
                2000,       // rows - ambil banyak
                true        // include content
            );

            $articles = is_array($articles) ? $articles : [];

            Log::info('✅ Articles fetched for mining', ['count' => count($articles)]);

            $stopwords = $this->getStopwords();

            foreach ($articles as $article) {
                // Filter sentiment kalau bukan "all"
                if ($sentiment !== '2') {
                    $articleSentiment = $article['class_sentiment']
                                     ?? $article['sentiment_id']
                                     ?? '0';
                    $sentimentStr = strtolower($article['sentiment'] ?? '');
                    if (str_contains($sentimentStr, 'positif') || str_contains($sentimentStr, 'positive')) {
                        $articleSentiment = '0';
                    } elseif (str_contains($sentimentStr, 'negatif') || str_contains($sentimentStr, 'negative')) {
                        $articleSentiment = '-1';
                    } elseif (str_contains($sentimentStr, 'netral') || str_contains($sentimentStr, 'neutral')) {
                        $articleSentiment = '1';
                    }
                    if ((string)$articleSentiment !== (string)$sentiment) continue;
                }

                // Mine dari title (bobot x3 karena judul lebih penting)
                $title = strip_tags($article['title'] ?? '');
                $titleWords = $this->extractWords($title, $stopwords);
                foreach ($titleWords as $word => $count) {
                    $phrases[$word] = ($phrases[$word] ?? 0) + ($count * 3);
                }

                // Mine dari content
                $content = strip_tags($article['content'] ?? '');
                if (strlen($content) > 50) {
                    $contentWords = $this->extractWords($content, $stopwords);
                    foreach ($contentWords as $word => $count) {
                        $phrases[$word] = ($phrases[$word] ?? 0) + $count;
                    }
                }
            }

            Log::info('✅ Articles text-mined', ['unique_words' => count($phrases)]);
        } catch (\Exception $e) {
            Log::warning('⚠️ Articles mining failed', ['error' => $e->getMessage()]);
        }

        // ── 3. SUPPLEMENT: Hashtags ──────────────────────────────────
        try {
            $hashtagsData = $this->mkClient->topHashtags($projectId, 'all', $startDate, $endDate);
            $hashtags = $hashtagsData['data'] ?? $hashtagsData ?? [];
            if (is_array($hashtags)) {
                foreach ($hashtags as $item) {
                    if (!is_array($item)) continue;
                    $tag   = ltrim($item['hashtag'] ?? '', '#');
                    $count = (int)($item['count'] ?? 1);
                    if (mb_strlen($tag) >= 3) {
                        $phrases[$tag] = ($phrases[$tag] ?? 0) + (int)($count * 2);
                    }
                }
            }
        } catch (\Exception $e) {
            Log::warning('⚠️ Hashtags failed', ['error' => $e->getMessage()]);
        }

        // ── 4. Cleanup & filter ──────────────────────────────────────
        $banned = [
            'http', 'https', 'www', 'com', 'net', 'org', 'co', 'id',
            'quot', 'amp', 'nbsp', 'ndash', 'mdash', 'rsquo', 'ldquo',
            'rdquo', 'lsquo', 'hellip', 'raquo', 'laquo',
        ];

        $phrases = array_filter($phrases, function ($word) use ($banned) {
            $lower = mb_strtolower($word, 'UTF-8');
            return mb_strlen($word, 'UTF-8') >= 3
                && mb_strlen($word, 'UTF-8') <= 30
                && !in_array($lower, $banned)
                && !is_numeric($word)
                && !str_starts_with($word, '&')
                && !str_starts_with($word, '@')
                && !preg_match('/^[^a-zA-Z\x{00C0}-\x{024F}\x{0370}-\x{03FF}]/u', $word);
        }, ARRAY_FILTER_USE_KEY);

        arsort($phrases);
        $phrases = array_slice($phrases, 0, 200, true);

        Log::info('✅ Word Cloud final', ['total' => count($phrases)]);

        return response()->json([
            'success' => true,
            'data'    => ['data' => ['phrases' => $phrases]],
            'meta'    => ['total_words' => count($phrases)],
        ]);

    } catch (\Exception $e) {
        Log::error('❌ News Word Cloud Error', ['error' => $e->getMessage()]);
        return response()->json(['success' => false, 'error' => 'Failed to fetch word cloud data'], 500);
    }
}

// ── Helper: extract & count words dari text ──────────────────────────
private function extractWords(string $text, array $stopwords): array
{
    // Bersihkan HTML entities
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = preg_replace('/(https?:\/\/[^\s]+)/', ' ', $text);
    $text = preg_replace('/[^\p{L}\s\-]/u', ' ', $text);
    $text = preg_replace('/\s+/', ' ', trim($text));

    $words = preg_split('/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
    $freq  = [];

    foreach ($words as $word) {
        $word  = trim($word, '-');
        $lower = mb_strtolower($word, 'UTF-8');

        if (mb_strlen($word, 'UTF-8') < 3)    continue;
        if (mb_strlen($word, 'UTF-8') > 30)   continue;
        if (is_numeric($word))                 continue;
        if (in_array($lower, $stopwords))      continue;
        if (str_starts_with($word, '&'))       continue;

        // Title case supaya konsisten
        $word = mb_convert_case($word, MB_CASE_TITLE, 'UTF-8');
        $freq[$word] = ($freq[$word] ?? 0) + 1;
    }

    return $freq;
}

// ── Helper: daftar stopwords ID + EN ────────────────────────────────
private function getStopwords(): array
{
    return [
        // Indonesia
        'yang','dan','di','dari','untuk','pada','dengan','ini','itu',
        'adalah','akan','ada','juga','atau','dalam','ke','tidak','sudah',
        'dapat','telah','oleh','sebagai','saat','lebih','bisa','tersebut',
        'bagi','antara','saja','melalui','hingga','nya','kami','kita',
        'anda','mereka','dia','saya','kamu','apa','siapa','dimana','kapan',
        'mengapa','bagaimana','hari','tahun','bulan','waktu','sangat',
        'sebuah','setelah','sebelum','ketika','karena','namun','tetapi',
        'jika','maka','bahwa','agar','supaya','pun','lagi','masih','hanya',
        'atas','bawah','depan','belakang','sini','sana','situ','begitu',
        'seperti','semua','setiap','beberapa','para','telah','sedang',
        'pernah','belum','tidak','bukan','jangan','nih','deh','dong',
        'sih','loh','kan','ya','yah','wah','oh','ah','eh',
        // English
        'the','a','an','and','or','but','in','on','at','to','for',
        'of','with','by','from','as','is','was','are','were','be',
        'been','being','have','has','had','do','does','did','will',
        'would','could','should','may','might','must','can','this',
        'that','these','those','i','you','he','she','it','we','they',
        'my','your','his','her','its','our','their','what','which',
        'who','when','where','why','how','all','each','every','both',
        'few','more','most','other','some','such','than','then','too',
        'very','just','about','into','after','before','between','through',
        // HTML entities yang lolos
        'quot','amp','nbsp','ndash','mdash','rsquo','ldquo','rdquo',
        'lsquo','hellip','raquo','laquo','apos',
    ];
}
    private function extractPhrasesFromMentions($mentions, $sentiment): array
    {
        $wordFreq = [];
        $stopwords = [
            'yang', 'dan', 'di', 'dari', 'untuk', 'pada', 'dengan', 'ini', 'itu',
            'adalah', 'akan', 'ada', 'juga', 'atau', 'dalam', 'ke', 'tidak',
            'sudah', 'dapat', 'telah', 'oleh', 'sebagai', 'saat', 'lebih', 'bisa',
            'tersebut', 'bagi', 'antara', 'saja', 'melalui', 'hingga', 'nya', 'kami',
            'kita', 'anda', 'mereka', 'dia', 'saya', 'kamu', 'apa', 'siapa', 'dimana',
            'kapan', 'mengapa', 'bagaimana', 'hari', 'tahun', 'bulan', 'waktu',
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'be',
            'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
            'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this',
            'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they',
        ];

        foreach ($mentions as $mention) {
            if ($sentiment !== '2') {
                $mentionSentiment = $mention['sentiment'] ?? '1';
                if ($mentionSentiment !== $sentiment) continue;
            }

            $content = $mention['content'] ?? '';
            $content = preg_replace('/(https?:\/\/[^\s]+)/', '', $content);
            $content = preg_replace('/@\w+/', '', $content);
            $content = preg_replace('/#(\w+)/', '$1', $content);
            $content = preg_replace('/[^\p{L}\s]/u', ' ', $content);

            $words = preg_split('/\s+/', $content, -1, PREG_SPLIT_NO_EMPTY);
            foreach ($words as $word) {
                $word = trim($word);
                $wordLower = mb_strtolower($word, 'UTF-8');
                $word = mb_convert_case($word, MB_CASE_TITLE, 'UTF-8');
                if (mb_strlen($word, 'UTF-8') >= 3 && mb_strlen($word, 'UTF-8') <= 25 && !in_array($wordLower, $stopwords) && !is_numeric($word)) {
                    $wordFreq[$word] = ($wordFreq[$word] ?? 0) + 1;
                }
            }
        }

        arsort($wordFreq);
        return array_slice($wordFreq, 0, 80, true);
    }

public function topPublisherPage(Request $request)
{
    try {
        $projects  = $this->getAllProjects();           // ← tambah ini
        $projectId = $request->query('project_id', session('selected_project_id'));

        if (!$projectId && count($projects) > 0) {     // ← auto-select first project
            $projectId = $projects[0]['id'] ?? null;
        }

        if (!$projectId) {
            return redirect()->route('mk.dashboard')->with('error', 'Please select a project first');
        }

        session(['selected_project_id' => $projectId]);

        return view('mk.news.top-publisher', [
            'projectId' => $projectId,
            'startDate' => $request->query('start_date', now()->subDays(6)->format('Y-m-d')),
            'endDate'   => $request->query('end_date', now()->format('Y-m-d')),
            'projects'  => $projects,   // ← ini yang kurang, penyebab error
        ]);
    } catch (\Exception $e) {
        Log::error('Top Publisher Page Error', ['error' => $e->getMessage()]);
        return redirect()->route('mk.dashboard')->with('error', 'Failed to load Top Publisher page');
    }
}
public function topPublisherData(Request $request)
{
    try {
        $projectId = $request->query('project_id');
        $startDate = $request->query('start_date');
        $endDate   = $request->query('end_date');
        $newsType  = $request->query('news_type', 'article');

        if (!$projectId) {
            return response()->json(['success' => false, 'error' => 'Project ID is required'], 400);
        }

        // ══════════════════════════════════════════════════════════
        // 1. Fetch article COUNT per publisher (topPublisher API)
        //    Returns: { "antaranews.com": 321, "liputan6.com": 161, ... }
        // ══════════════════════════════════════════════════════════
        $publishersData = $this->mkClient->topPublisher(
            $projectId, $startDate, $endDate, 0, 23, 1000, $newsType
        );

        // Bangun lookup keyed by normalized domain
        $publishers = [];
        $rank = 1;
        foreach ($publishersData as $domain => $count) {
            $key = preg_replace('/^www\./', '', strtolower(trim($domain)));
            $publishers[$key] = [
                'rank'     => $rank++,
                'domain'   => $domain,
                'count'    => (int) $count,
                'mentions' => 0,   // diisi di step 2
            ];
        }

        // ══════════════════════════════════════════════════════════
        // 2. Fetch articles detail → group by publisher → mentions
        //    articles() sudah ada, gunakan doc + rows besar
        //    include_content = false agar lebih cepat
        // ══════════════════════════════════════════════════════════
        try {
            $articles = $this->mkClient->articles(
                $projectId,
                'doc',   // media type: online news
                $startDate,
                $endDate,
                0,       // sentiment_id: 0 = all
                23,      // end_hour
                0,       // offset
                5000,    // rows — ambil banyak untuk coverage akurat
                false    // include_content = false, lebih cepat
            );

            $articles = is_array($articles) ? $articles : [];

            // ── Hitung mentions per domain ──────────────────────────
            $menMap = [];
            foreach ($articles as $article) {
                // Coba ambil publisher dari berbagai field
                $pub = trim(
                    $article['publisher']   ??
                    $article['hostname']    ??
                    $article['source_name'] ??
                    $article['domain']      ?? ''
                );

                // Fallback: parse dari URL
                if (!$pub) {
                    $url = (string) ($article['url'] ?? $article['link'] ?? '');
                    if ($url) {
                        $parsed = parse_url($url);
                        $pub    = $parsed['host'] ?? '';
                    }
                }

                $pub = preg_replace('/^www\./', '', strtolower(trim($pub)));
                if (!$pub) continue;

                $menMap[$pub] = ($menMap[$pub] ?? 0) + 1;
            }

            Log::info('✅ topPublisherData — articles fetched for mentions', [
                'articles_total'    => count($articles),
                'unique_publishers' => count($menMap),
                'sample'            => array_slice($menMap, 0, 5, true),
            ]);

            // ── Attach mentions ke setiap publisher ─────────────────
            foreach ($publishers as $key => &$pub) {
                $men = $menMap[$key] ?? 0;

                // Partial fallback: "nasional.kompas.com" → check "kompas.com"
                if (!$men && substr_count($key, '.') >= 2) {
                    $parts   = explode('.', $key);
                    $rootKey = implode('.', array_slice($parts, -2));
                    foreach ($menMap as $mKey => $mVal) {
                        if (str_ends_with($mKey, $rootKey)) {
                            $men += $mVal;
                        }
                    }
                }

                $pub['mentions'] = $men;
            }
            unset($pub);

            Log::info('✅ topPublisherData — merge done', [
                'top5' => array_map(
                    fn($p) => "{$p['domain']} art:{$p['count']} men:{$p['mentions']}",
                    array_slice(array_values($publishers), 0, 5)
                ),
            ]);

        } catch (\Exception $e) {
            // Gagal fetch articles detail → lanjut dengan mentions = 0
            Log::warning('⚠️ topPublisherData: articles detail fetch failed', [
                'error' => $e->getMessage(),
            ]);
        }

        // Re-index jadi plain array, sorted by count DESC (sudah dari API)
        $publishers    = array_values($publishers);
        $totalArticles = array_sum(array_column($publishers, 'count'));
        $totalMentions = array_sum(array_column($publishers, 'mentions'));

        return response()->json([
            'success' => true,
            'data'    => $publishers,
            'meta'    => [
                'total_publishers' => count($publishers),
                'total_articles'   => $totalArticles,
                'total_mentions'   => $totalMentions,
            ],
        ]);

    } catch (\Exception $e) {
        Log::error('❌ topPublisherData Error', ['error' => $e->getMessage()]);
        return response()->json(['success' => false, 'error' => 'Failed to fetch top publisher data'], 500);
    }
}
    public function articlesPage(Request $request)
    {
        try {
            $projectId = $request->query('project_id', session('selected_project_id'));
            if (!$projectId) {
                return redirect()->route('mk.dashboard')->with('error', 'Please select a project first');
            }
            session(['selected_project_id' => $projectId]);
            return view('mk.news.articles', [
                'projectId' => $projectId,
                'startDate' => $request->query('start_date', now()->subDays(6)->format('Y-m-d')),
                'endDate'   => $request->query('end_date', now()->format('Y-m-d')),
            ]);
        } catch (\Exception $e) {
            return redirect()->route('mk.dashboard')->with('error', 'Failed to load Articles page');
        }
    }
public function articlesData(Request $request)
{
    try {
        $projectId = $request->query('project_id');
        $startDate = $request->query('start_date');
        $endDate   = $request->query('end_date');
        $media     = $request->query('media', 'doc');
        $sentiment = $request->query('sentiment', 'all');
        $maxRows   = (int) $request->query('rows', 99999); // max total yang mau diambil
        $start     = (int) $request->query('start', 0);

        if (!$projectId) {
            return response()->json(['success' => false, 'error' => 'Project ID is required'], 400);
        }

        // ✅ Loop fetch sampai semua artikel terambil dari MK API
        $allArticles = [];
        $offset      = $start;
        $batchSize   = 1000; // MK API max per request

        do {
            $batch = $this->mkClient->articles(
                $projectId,
                $media,
                $startDate,
                $endDate,
                0,          // sentiment_id (0 = all)
                23,         // end_hour
                $offset,    // offset
                $batchSize, // rows per batch
                true        // include content
            );

            $batch = is_array($batch) ? array_values($batch) : [];

            if (empty($batch)) break;

            $allArticles = array_merge($allArticles, $batch);
            $offset     += count($batch);

            Log::info("📄 Articles batch fetched", [
                'offset'      => $offset,
                'batch_count' => count($batch),
                'total_so_far' => count($allArticles),
            ]);

        } while (count($batch) === $batchSize && count($allArticles) < $maxRows);

        Log::info("✅ Total articles fetched", ['total' => count($allArticles)]);

        $totalQuotesBeforeFilter = 0;
        $totalQuotesAfterFilter  = 0;
        $articlesWithValidQuotes = 0;
        $quotesFilteredOut       = 0;

        $articles = array_map(function ($article) use (
            &$totalQuotesBeforeFilter, &$totalQuotesAfterFilter,
            &$articlesWithValidQuotes, &$quotesFilteredOut
        ) {
            $article['title']           = $article['title']           ?? 'Untitled';
            $article['publisher']       = $article['publisher']       ?? 'Unknown Publisher';
            $article['url']             = $article['url']             ?? '#';
            $article['date_created']    = $article['date_created']    ?? now()->toDateTimeString();
            $article['content']         = $article['content']         ?? '';
            $article['sentiment']       = $article['sentiment']       ?? 'Neutral';
            $article['sentiment_class'] = $article['sentiment_class'] ?? 'neutral';

            $quotes = $article['quotes'] ?? [];
            $totalQuotesBeforeFilter += is_array($quotes) ? count($quotes) : 0;

            if (is_array($quotes) && count($quotes) > 0) {
                $validQuotes = array_filter($quotes, function ($quote) use (&$quotesFilteredOut) {
                    if (!is_array($quote))             { $quotesFilteredOut++; return false; }
                    if (!isset($quote['Kutipan']))      { $quotesFilteredOut++; return false; }
                    if (trim($quote['Kutipan']) === '') { $quotesFilteredOut++; return false; }
                    return true;
                });
                $quotes = array_values($validQuotes);
            } else {
                $quotes = [];
            }

            $totalQuotesAfterFilter += count($quotes);
            if (count($quotes) > 0) $articlesWithValidQuotes++;

            $article['quotes']       = $quotes;
            $article['total_quotes'] = count($quotes);
            return $article;

        }, $allArticles);

        // ✅ Filter by sentiment jika bukan 'all'
        if ($sentiment !== 'all') {
            $articles = array_values(array_filter($articles, function ($article) use ($sentiment) {
                $articleSentiment = $article['class_sentiment'] ?? $article['sentiment_class'] ?? '0';
                $sentimentLower   = strtolower($article['sentiment'] ?? '');
                if     ($sentimentLower === 'positive' || $sentimentLower === 'positif') $articleSentiment = '1';
                elseif ($sentimentLower === 'negative' || $sentimentLower === 'negatif') $articleSentiment = '-1';
                elseif ($sentimentLower === 'neutral'  || $sentimentLower === 'netral')  $articleSentiment = '0';
                return $articleSentiment == $sentiment;
            }));
        }

        $totalQuotes = array_sum(array_column($articles, 'total_quotes'));

        return response()->json([
            'success' => true,
            'data'    => $articles,
            'meta'    => [
                'total_articles'         => count($articles),
                'articles_with_quotes'   => $articlesWithValidQuotes,
                'total_quotes'           => $totalQuotes,
                'avg_quotes_per_article' => count($articles) > 0
                    ? round($totalQuotes / count($articles), 2)
                    : 0,
                'sentiment_filter'       => $sentiment,
                'media_type'             => $media,
                'start'                  => $start,
                'rows_fetched'           => count($articles), // ✅ total aktual
            ],
        ]);

    } catch (\Exception $e) {
        Log::error('❌ Articles API Error', ['error' => $e->getMessage()]);
        return response()->json(['success' => false, 'error' => 'Failed to fetch articles data'], 500);
    }
}



    public function newsTimelinePage(Request $request)
    {
        try {
            $projectId = $request->query('project_id', session('selected_project_id'));
            if (!$projectId) {
                return redirect()->route('mk.dashboard')->with('error', 'Please select a project first');
            }
            session(['selected_project_id' => $projectId]);

            return view('mk.news.timeline', [
                'projects'  => $this->getAllProjects(),
                'projectId' => $projectId,
                'startDate' => $request->query('start_date', now()->subDays(6)->format('Y-m-d')),
                'endDate'   => $request->query('end_date', now()->format('Y-m-d')),
            ]);
        } catch (\Exception $e) {
            return redirect()->route('mk.dashboard')->with('error', 'Failed to load News Timeline page');
        }
    }

    public function newsMentionsData(Request $request)
    {
        try {
            $projectId = $request->query('project_id');
            $startDate = $request->query('start_date');
            $endDate   = $request->query('end_date');
            $start     = (int) $request->query('start', 0);
            $rows      = (int) $request->query('rows', 2000);

            if (!$projectId) {
                return response()->json(['success' => false, 'error' => 'Project ID is required'], 400);
            }

            Log::info('🔍 News Mentions Timeline Data Fetch', compact('projectId', 'startDate', 'endDate', 'start', 'rows'));

            $raw      = $this->mkClient->mentions($projectId, $startDate, $endDate, 0, 23, true, $start, $rows);
            // ✅ FIX: extractArray handles raw [], {data:[]}, {success,data}
            $mentions = $this->extractArray($raw);

            // ═══════════════════════════════════════════════════════
            // DEBUG: Lihat distribusi media_type_id dari raw mentions
            // Ini penting untuk diagnosa kenapa Online News = 0
            // ═══════════════════════════════════════════════════════
            $mtidDist = [];
            $tcodeDist = [];
            $sample = [];
            foreach ($mentions as $i => $m) {
                $mtid  = (string)($m['media_type_id'] ?? 'NULL');
                $tcode = (string)($m['tcode'] ?? $m['media_type'] ?? 'NULL');
                $mtidDist[$mtid]   = ($mtidDist[$mtid] ?? 0) + 1;
                $tcodeDist[$tcode] = ($tcodeDist[$tcode] ?? 0) + 1;
                if ($i < 5) {
                    $sample[] = [
                        'id'            => substr((string)($m['id'] ?? $m['docid'] ?? ''), 0, 20),
                        'media_type_id' => $m['media_type_id'] ?? 'NULL',
                        'media_type'    => $m['media_type'] ?? 'NULL',
                        'tcode'         => $m['tcode'] ?? 'NULL',
                        'url'           => substr((string)($m['url'] ?? ''), 0, 40),
                    ];
                }
            }
            arsort($mtidDist);
            Log::info('🔬 RAW MENTIONS DEBUG — media_type_id distribution', [
                'total'        => count($mentions),
                'mtid_dist'    => $mtidDist,
                'tcode_dist'   => $tcodeDist,
                'sample_items' => $sample,
            ]);
            // ═══════════════════════════════════════════════════════

            Log::info('✅ News Mentions fetched', ['total' => count($mentions), 'start' => $start]);

            return response()->json([
                'success' => true,
                'data'    => $mentions,
                'meta'    => ['total' => count($mentions), 'start' => $start, 'rows' => $rows],
            ]);

        } catch (\Exception $e) {
            Log::error('❌ News Mentions API Error', ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'error' => 'Failed to fetch mentions data'], 500);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // TikTok Top Status
    // ════════════════════════════════════════════════════════════════
    public function tiktokTopStatus(Request $request)
    {
        try {
            $projectId = $request->query('project_id');
            $startDate = $request->query('start_date');
            $endDate   = $request->query('end_date');
            $rows      = (int) $request->query('rows', 2000);
            $start     = (int) $request->query('start', 0);
            $sub       = $request->query('sub', 'postbylike');

            if (!$projectId) return response()->json(['success' => false, 'error' => 'Project ID is required'], 400);

            Log::info('🎵 TikTok Top Status Fetch', compact('projectId', 'startDate', 'endDate', 'rows', 'start', 'sub'));

            $raw  = $this->mkClient->tiktokTopStatus($projectId, $startDate, $endDate, 0, 23, $rows, $sub);
            // ✅ FIX: dulu pakai count((array)$data) yang return 1 meski kosong
            $data = $this->extractArray($raw);

            Log::info('tiktokTopStatus API response', [
                'project_id'  => $projectId,
                'sub'         => $sub,
                'total_items' => count($data),
                'first_item'  => count($data) > 0 ? array_slice($data[0], 0, 4) : null,
            ]);

            if (empty($data)) {
                Log::info('TikTok: no data from dedicated API, returning empty (frontend handles fallback)');
                return response()->json(['success' => true, 'data' => [], 'meta' => ['total' => 0, 'platform' => 'tiktok', 'sub' => $sub]]);
            }

            $normalised = array_map(fn($item) => $this->normaliseTiktok($item), $data);
            return response()->json(['success' => true, 'data' => $normalised, 'meta' => ['total' => count($normalised), 'platform' => 'tiktok', 'sub' => $sub]]);

        } catch (\Exception $e) {
            Log::error('TikTok Top Status Error', ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'error' => 'Failed to fetch TikTok data'], 500);
        }
    }

    private function normaliseTiktok(array $item): array
    {
        $handle = $item['author_scr_name'] ?? $item['author_id'] ?? '';
        return [
            '_platform'       => 'tiktok',
            'media_type_id'   => '6',
            'id'              => $item['id'] ?? $item['docid'] ?? '',
            'url'             => $item['url'] ?? '',
            'content'         => strip_tags($item['content'] ?? $item['name'] ?? ''),
            'author_name'     => $handle,
            'author_handle'   => $handle,
            'avatar_url'      => ($item['image'] ?? '') ?: '',
            'date_created'    => $item['date_created'] ?? '',
            'num_likes'       => (int) ($item['likes'] ?? $item['num_likes'] ?? $item['freq'] ?? 0),
            'num_comments'    => (int) ($item['comments'] ?? $item['num_comments'] ?? 0),
            'num_shares'      => (int) ($item['shares'] ?? 0),
            'num_views'       => (int) ($item['views'] ?? $item['num_views'] ?? 0),
            'num_followers'   => (int) ($item['num_followers'] ?? 0),
            'class_sentiment' => (string) ($item['sentiment'] ?? $item['class_sentiment'] ?? '0'),
            'mention_type'    => $item['mention_type'] ?? 'video',
            'hostname'        => 'tiktok.com',
        ];
    }

    // ════════════════════════════════════════════════════════════════
    // Instagram Top Status
    // ════════════════════════════════════════════════════════════════
    public function igTopStatus(Request $request)
    {
        try {
            $projectId = $request->query('project_id');
            $startDate = $request->query('start_date');
            $endDate   = $request->query('end_date');
            $rows      = (int) $request->query('rows', 2000);
            $start     = (int) $request->query('start', 0);
            $sub       = $request->query('sub', 'postbylike');

            if (!$projectId) {
                return response()->json(['success' => false, 'error' => 'Project ID is required'], 400);
            }

            Log::info('📷 Instagram Top Status Fetch', compact('projectId', 'startDate', 'endDate', 'rows', 'start', 'sub'));

            $data = [];

            try {
                $raw  = $this->mkClient->igTopStatus($projectId, $startDate, $endDate, 0, 23, $rows, $sub);
                // ✅ FIX: extractArray instead of count((array)$data)
                $data = $this->extractArray($raw);
                Log::info('✅ IG dedicated API returned', ['count' => count($data)]);
            } catch (\Exception $e) {
                Log::warning('⚠️ IG dedicated API failed, falling back to mentions', ['error' => $e->getMessage()]);
            }

            if (empty($data)) {
                Log::info('📋 Instagram: using mentions fallback');
                $rawMentions = $this->mkClient->mentions($projectId, $startDate, $endDate, 0, 23, true, $start, $rows);
                $mentions    = $this->extractArray($rawMentions);

                $data = array_values(array_filter($mentions, function ($item) {
                    $mt  = strtolower((string) ($item['media_type_id'] ?? $item['media_type'] ?? $item['tcode'] ?? ''));
                    $id  = (string) ($item['id'] ?? $item['docid'] ?? '');
                    $url = (string) ($item['url'] ?? '');
                    return $mt === '3'
                        || str_contains($mt, 'ig')
                        || str_contains($mt, 'instagram')
                        || str_starts_with($id, 'in-')
                        || str_contains($url, 'instagram.com');
                }));

                usort($data, fn($a, $b) =>
                    (int)($b['num_likes'] ?? $b['likes'] ?? $b['freq'] ?? 0)
                    - (int)($a['num_likes'] ?? $a['likes'] ?? $a['freq'] ?? 0)
                );

                Log::info('📋 Instagram fallback result', ['count' => count($data)]);
            }

            $normalised = array_map(fn($item) => $this->normaliseInstagram($item), $data);

            Log::info('✅ Instagram Top Status final', ['total' => count($normalised)]);

            return response()->json([
                'success' => true,
                'data'    => $normalised,
                'meta'    => ['total' => count($normalised), 'platform' => 'instagram', 'sub' => $sub],
            ]);

        } catch (\Exception $e) {
            Log::error('❌ Instagram Top Status Error', ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'error' => 'Failed to fetch Instagram data'], 500);
        }
    }

    private function normaliseInstagram(array $item): array
    {
        $handle    = $item['author_scr_name'] ?? $item['author_id'] ?? '';
        $authorId  = $item['author_id'] ?? $handle;
        $rawImage  = $item['image'] ?? '';

        $avatarUrl = ($rawImage && str_starts_with($rawImage, 'http'))
            ? $rawImage
            : ($handle ? "https://unavatar.io/instagram/{$authorId}" : '');

        return [
            '_platform'       => 'ig',
            'media_type_id'   => '3',
            'id'              => $item['id'] ?? $item['docid'] ?? '',
            'url'             => $item['url'] ?? '',
            'content'         => strip_tags($item['content'] ?? $item['name'] ?? ''),
            'author_name'     => $handle,
            'author_handle'   => $authorId,
            'avatar_url'      => $avatarUrl,
            'date_created'    => $item['date_created'] ?? '',
            'num_likes'       => (int) ($item['num_likes'] ?? $item['likes'] ?? $item['freq'] ?? 0),
            'num_comments'    => (int) ($item['num_comments'] ?? $item['comments'] ?? 0),
            'num_shares'      => (int) ($item['shares'] ?? 0),
            'num_views'       => (int) ($item['views'] ?? $item['num_views'] ?? 0),
            'num_followers'   => (int) ($item['num_followers'] ?? 0),
            'interaction'     => (int) ($item['interaction'] ?? $item['interaction_with_post'] ?? 0),
            'class_sentiment' => (string) ($item['sentiment'] ?? $item['class_sentiment'] ?? '0'),
            'sentiment_str'   => $item['sentiment_str'] ?? '',
            'mention_type'    => $item['mention_type'] ?? 'image',
            'hostname'        => 'instagram.com',
        ];
    }

    // ════════════════════════════════════════════════════════════════
    // Facebook Top Status
    // ════════════════════════════════════════════════════════════════
    public function fbTopStatusApi(Request $request)
    {
        try {
            $projectId = $request->query('project_id');
            $startDate = $request->query('start_date');
            $endDate   = $request->query('end_date');
            $rows      = (int) $request->query('rows', 2000);
            $start     = (int) $request->query('start', 0);
            $sub       = $request->query('sub', 'fblike');

            if (!$projectId) {
                return response()->json(['success' => false, 'error' => 'Project ID is required'], 400);
            }

            Log::info('📘 Facebook Top Status Fetch', compact('projectId', 'startDate', 'endDate', 'rows', 'start', 'sub'));

            $data = [];

            try {
                $raw  = $this->mkClient->fbTopStatus($projectId, $startDate, $endDate, 0, 23, $rows, $sub);
                // ✅ FIX: extractArray instead of count((array)$data)
                $data = $this->extractArray($raw);
                Log::info('✅ FB dedicated API returned', ['count' => count($data)]);
            } catch (\Exception $e) {
                Log::warning('⚠️ FB dedicated API failed, falling back to mentions', ['error' => $e->getMessage()]);
            }

            if (empty($data)) {
                Log::info('📋 Facebook: using mentions fallback');
                $rawMentions = $this->mkClient->mentions($projectId, $startDate, $endDate, 0, 23, true, $start, $rows);
                $mentions    = $this->extractArray($rawMentions);

                // ✅ FIX: Filter by tcode/media_type string, bukan media_type_id
                // Karena media_type_id tidak konsisten antar project
                // Di project ini: media_type="fb", tcode="fb-post"/"fb-comment"
                $data = array_values(array_filter($mentions, function ($item) {
                    $mt    = strtolower((string) ($item['media_type'] ?? ''));
                    $tcode = strtolower((string) ($item['tcode'] ?? ''));
                    $id    = (string) ($item['id'] ?? '');
                    $url   = (string) ($item['url'] ?? '');
                    return $mt === 'fb' || $mt === 'facebook'
                        || str_starts_with($tcode, 'fb-')
                        || str_starts_with($id, 'fb-')
                        || str_contains($url, 'facebook.com')
                        || str_contains($url, 'fb.com');
                }));

                usort($data, fn($a, $b) =>
                    (int)($b['num_likes'] ?? $b['likes'] ?? 0)
                    - (int)($a['num_likes'] ?? $a['likes'] ?? 0)
                );

                Log::info('📋 Facebook fallback result', ['count' => count($data)]);
            }

            $normalised = array_map(fn($item) => $this->normaliseFacebook($item), $data);

            return response()->json([
                'success' => true,
                'data'    => $normalised,
                'meta'    => ['total' => count($normalised), 'platform' => 'facebook', 'sub' => $sub],
            ]);

        } catch (\Exception $e) {
            Log::error('❌ Facebook Top Status Error', ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'error' => 'Failed to fetch Facebook data'], 500);
        }
    }

    private function normaliseFacebook(array $item): array
    {
        $handle = $item['author_scr_name'] ?? $item['author_id'] ?? '';
        $name   = $item['author_name'] ?? $handle;
        return [
            '_platform'       => 'fb',
            'media_type_id'   => '2',
            'id'              => $item['id'] ?? $item['docid'] ?? '',
            'url'             => $item['url'] ?? '',
            'content'         => strip_tags($item['content'] ?? $item['name'] ?? ''),
            'author_name'     => $name,
            'author_handle'   => $handle,
            'avatar_url'      => ($item['image'] ?? ''),
            'date_created'    => $item['date_created'] ?? '',
            'num_likes'       => (int) ($item['likes'] ?? $item['num_likes'] ?? $item['freq'] ?? 0),
            'num_comments'    => (int) ($item['comments'] ?? $item['num_comments'] ?? 0),
            'num_shares'      => (int) ($item['shares'] ?? 0),
            'num_views'       => (int) ($item['views'] ?? $item['view_cnt'] ?? $item['num_views'] ?? 0),
            'num_followers'   => (int) ($item['num_followers'] ?? 0),
            'class_sentiment' => (string) ($item['sentiment'] ?? $item['sentiment_id'] ?? $item['class_sentiment'] ?? '0'),
            'mention_type'    => $item['mention_type'] ?? 'post',
            'hostname'        => 'facebook.com',
        ];
    }

    // ════════════════════════════════════════════════════════════════
    // YouTube Top Status
    // ════════════════════════════════════════════════════════════════
    public function ytbTopStatus(Request $request)
    {
        try {
            $projectId = $request->query('project_id');
            $startDate = $request->query('start_date');
            $endDate   = $request->query('end_date');
            $rows      = (int) $request->query('rows', 2000);
            $start     = (int) $request->query('start', 0);
            $sub       = $request->query('sub', 'postbyview');

            if (!$projectId) {
                return response()->json(['success' => false, 'error' => 'Project ID is required'], 400);
            }

            Log::info('▶️ YouTube Top Status Fetch', compact('projectId', 'startDate', 'endDate', 'rows', 'start', 'sub'));

            $data = [];

            try {
                $raw  = $this->mkClient->ytbTopStatus($projectId, $startDate, $endDate, 0, 23, $rows, $sub);
                $data = $this->extractArray($raw);
                Log::info('✅ YT dedicated API returned', ['count' => count($data)]);
            } catch (\Exception $e) {
                Log::warning('⚠️ YT dedicated API failed, falling back to mentions', ['error' => $e->getMessage()]);
            }

            if (empty($data)) {
                Log::info('📋 YouTube: using mentions fallback');
                $rawMentions = $this->mkClient->mentions($projectId, $startDate, $endDate, 0, 23, true, $start, $rows);
                $mentions    = $this->extractArray($rawMentions);

                $data = array_values(array_filter($mentions, function ($item) {
                    $mt  = strtolower((string) ($item['media_type_id'] ?? $item['media_type'] ?? $item['tcode'] ?? ''));
                    $id  = (string) ($item['id'] ?? $item['docid'] ?? '');
                    $url = (string) ($item['url'] ?? '');
                    return $mt === '4'
                        || str_contains($mt, 'ytb')
                        || str_contains($mt, 'youtube')
                        || str_starts_with($id, 'yt-')
                        || str_contains($url, 'youtube.com')
                        || str_contains($url, 'youtu.be');
                }));

                usort($data, fn($a, $b) =>
                    (int)($b['num_likes'] ?? 0) - (int)($a['num_likes'] ?? 0)
                );
            }

            $normalised = array_map(fn($item) => [
                '_platform'       => 'ytb',
                'media_type_id'   => '4',
                'id'              => $item['id'] ?? $item['docid'] ?? '',
                'url'             => $item['url'] ?? '',
                'content'         => strip_tags($item['content'] ?? $item['name'] ?? ''),
                'author_name'     => $item['author_name'] ?? $item['author_scr_name'] ?? $item['channel_title'] ?? '',
                'author_handle'   => $item['author_scr_name'] ?? $item['channel_name'] ?? '',
                'avatar_url'      => $item['image'] ?? $item['thumbnail'] ?? '',
                'date_created'    => $item['date_created'] ?? '',
                'num_likes'       => (int) ($item['num_likes'] ?? $item['likes'] ?? 0),
                'num_comments'    => (int) ($item['num_comments'] ?? $item['comments'] ?? 0),
                'num_shares'      => (int) ($item['num_shares'] ?? $item['shares'] ?? 0),
                'num_views'       => (int) ($item['num_views'] ?? $item['views'] ?? 0),
                'num_followers'   => 0,
                'class_sentiment' => (string) ($item['sentiment'] ?? $item['class_sentiment'] ?? '0'),
                'mention_type'    => $item['mention_type'] ?? 'video',
                'hostname'        => 'youtube.com',
            ], $data);

            Log::info('✅ YouTube Top Status fetched', ['total' => count($normalised)]);

            return response()->json([
                'success' => true,
                'data'    => $normalised,
                'meta'    => ['total' => count($normalised), 'platform' => 'youtube'],
            ]);

        } catch (\Exception $e) {
            Log::error('❌ YouTube Top Status Error', ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'error' => 'Failed to fetch YouTube data'], 500);
        }
    }
    public function aiAnalysisPage(Request $request)
    {
        try {
            $projects  = $this->getAllProjects();
            $projectId = $request->query('project_id');

            if (!$projectId && count($projects) > 0) {
                $projectId = $projects[0]['id'] ?? null;
                if ($projectId) {
                    return redirect()->route('mk.news.ai-analysis', [
                        'project_id' => $projectId,
                        'start_date' => $request->query('start_date', now()->subDays(6)->format('Y-m-d')),
                        'end_date'   => $request->query('end_date', now()->format('Y-m-d')),
                    ]);
                }
            }

            return view('mk.news.ai-analysis')->with([
                'projectId' => $projectId,
                'startDate' => $request->query('start_date', now()->subDays(6)->format('Y-m-d')),
                'endDate'   => $request->query('end_date', now()->format('Y-m-d')),
                'projects'  => $projects,
            ]);

        } catch (\Exception $e) {
            Log::error('News AI Analysis Page Error', ['error' => $e->getMessage()]);
            return view('mk.news.ai-analysis')->with([
                'projectId' => null,
                'startDate' => now()->subDays(6)->format('Y-m-d'),
                'endDate'   => now()->format('Y-m-d'),
                'projects'  => [],
                'error'     => $e->getMessage(),
            ]);
        }
    }

public function aiAnalysisProxy(Request $request)
{
    try {
        $apiKey = env('GEMINI_API_KEY');

        if (!$apiKey) {
            return response()->json([
                'error' => 'GEMINI_API_KEY belum diset di .env — Daftar di aistudio.google.com',
            ], 500);
        }

        $messages  = $request->input('messages', []);
        $system    = $request->input('system', '');
        $maxTokens = (int) $request->input('max_tokens', 2000);

        if (empty($messages)) {
            return response()->json(['error' => 'Messages tidak boleh kosong'], 400);
        }

        // Bangun contents untuk Gemini
        $contents   = [];
        $firstAdded = false;

        foreach ($messages as $msg) {
            $role    = $msg['role'] === 'assistant' ? 'model' : 'user';
            $content = $msg['content'];

            if (!$firstAdded && $role === 'user' && !empty($system)) {
                $content    = $system . "\n\n---\n\n" . $content;
                $firstAdded = true;
            }

            $contents[] = [
                'role'  => $role,
                'parts' => [['text' => $content]],
            ];
        }

        // Model terbaru berdasarkan API key yang tersedia
        $models = [
            'gemini-2.5-flash',       // terbaru & terbaik
            'gemini-2.5-pro',         // paling powerful
            'gemini-2.0-flash',       // stable
            'gemini-2.0-flash-lite',  // paling ringan
            'gemini-flash-latest',    // alias latest
        ];

        $text      = '';
        $usedModel = '';

        foreach ($models as $model) {
            $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}";

            try {
                $response = \Illuminate\Support\Facades\Http::withHeaders([
                    'Content-Type' => 'application/json',
                ])->timeout(60)->post($endpoint, [
                    'contents'         => $contents,
                    'generationConfig' => [
                        'maxOutputTokens' => $maxTokens,
                        'temperature'     => 0.7,
                    ],
                ]);

                if ($response->status() === 429) {
                    Log::warning("Gemini model {$model} quota exceeded, trying next...");
                    continue;
                }

                if ($response->status() === 404) {
                    Log::warning("Gemini model {$model} not found, trying next...");
                    continue;
                }

                if ($response->failed()) {
                    Log::error('Gemini API Error', [
                        'model'  => $model,
                        'status' => $response->status(),
                        'body'   => $response->body(),
                    ]);
                    continue;
                }

                $data = $response->json();
                $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

                if (!empty($text)) {
                    $usedModel = $model;
                    Log::info("✅ Gemini response OK", ['model' => $model]);
                    break;
                }

            } catch (\Exception $e) {
                Log::warning("Gemini model {$model} error: " . $e->getMessage());
                continue;
            }
        }

        if (empty($text)) {
            return response()->json([
                'error' => 'Semua model Gemini sedang tidak tersedia atau quota habis. Coba lagi beberapa saat.',
            ], 429);
        }

        return response()->json([
            'content' => [
                ['type' => 'text', 'text' => $text]
            ],
            'model' => $usedModel,
        ]);

    } catch (\Illuminate\Http\Client\ConnectionException $e) {
        Log::error('Gemini Connection Error', ['error' => $e->getMessage()]);
        return response()->json(['error' => 'Tidak bisa terhubung ke Gemini API'], 503);
    } catch (\Exception $e) {
        Log::error('AI Proxy Error', ['error' => $e->getMessage()]);
        return response()->json(['error' => 'Internal server error: ' . $e->getMessage()], 500);
    }
}
public function newsTopicMapPage(Request $request)
{
    try {
        $projectId = $request->query('project_id', session('selected_project_id'));

        if (!$projectId) {
            return redirect()->route('mk.dashboard')
                ->with('error', 'Please select a project first');
        }

        session(['selected_project_id' => $projectId]);

        return view('mk.news.topic-map', [
            'projects'  => $this->getAllProjects(),
            'projectId' => $projectId,
            'startDate' => $request->query('start_date', now()->subDays(6)->format('Y-m-d')),
            'endDate'   => $request->query('end_date', now()->format('Y-m-d')),
        ]);

    } catch (\Exception $e) {
        Log::error('News Topic Map Page Error', ['error' => $e->getMessage()]);
        return redirect()->route('mk.dashboard')
            ->with('error', 'Failed to load News Topic Map page');
    }
}
public function updateSentiment(Request $request)
    {
        try {
            $projectId = $request->input('project_id');
            $docId     = $request->input('doc_id');
            $platform  = $request->input('platform', 'doc');
            $sentiment = $request->input('sentiment'); // '1', '-1', '0'
            $url       = $request->input('url', '');

            if (!$projectId || $sentiment === null) {
                return response()->json([
                    'success' => false,
                    'error'   => 'project_id dan sentiment wajib diisi',
                ], 400);
            }

            // Validasi nilai sentiment
            if (!in_array((string) $sentiment, ['1', '-1', '0'])) {
                return response()->json([
                    'success' => false,
                    'error'   => 'Nilai sentiment tidak valid. Gunakan: 1 (Positive), -1 (Negative), 0 (Neutral)',
                ], 400);
            }

            Log::info('🎯 Update Sentiment Request', [
                'project_id' => $projectId,
                'doc_id'     => $docId,
                'platform'   => $platform,
                'sentiment'  => $sentiment,
                'url'        => $url,
            ]);

            // Panggil MK API untuk update sentiment
            // Sesuaikan method mkClient dengan yang tersedia di MediaKernelsClient kamu
            $result = $this->mkClient->updateSentiment(
                $projectId,
                $docId,
                (int) $sentiment,
                $platform
            );

            Log::info('✅ Sentiment updated', [
                'doc_id'    => $docId,
                'sentiment' => $sentiment,
                'result'    => $result,
            ]);

            return response()->json([
                'success'   => true,
                'message'   => 'Sentiment berhasil diperbarui',
                'doc_id'    => $docId,
                'sentiment' => $sentiment,
                'platform'  => $platform,
            ]);

        } catch (\Exception $e) {
            Log::error('❌ Update Sentiment Error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json([
                'success' => false,
                'error'   => 'Gagal memperbarui sentiment: ' . $e->getMessage(),
            ], 500);
        }
    }
    // Di NewsController.php — tambah method ini

public function aiAnalysisData(Request $request)
{
    try {
        $projectId = $request->query('project_id');
        $startDate = $request->query('start_date');
        $endDate   = $request->query('end_date');

        if (!$projectId) {
            return response()->json(['success' => false, 'error' => 'Project ID required'], 400);
        }

        // ── 1. Fetch semua data paralel ──
        $articlesRaw    = $this->mkClient->articles($projectId, 'doc', $startDate, $endDate, 0, 23, 0, 100, true);
        $publishersRaw  = $this->mkClient->topPublisher($projectId, $startDate, $endDate, 0, 23, 20, 'article');
        $sentimentRaw   = $this->mkClient->sentimentTotal($projectId, $startDate, $endDate);
        $wordCloudRaw   = $this->mkClient->wordCloud($projectId, $startDate, 0, $endDate, 23, '2');

        // ── 2. Parse articles ──
        $articles = is_array($articlesRaw) ? $articlesRaw : ($articlesRaw['data'] ?? []);

        $sentCounts = ['positive' => 0, 'negative' => 0, 'neutral' => 0];
        $parsedArticles = [];

        foreach ($articles as $article) {
            if (!is_array($article)) continue;

            // Normalize sentiment
            $sentStr = strtolower($article['sentiment'] ?? '');
            if (str_contains($sentStr, 'pos')) {
                $bucket = 'positive';
            } elseif (str_contains($sentStr, 'neg')) {
                $bucket = 'negative';
            } else {
                $bucket = 'neutral';
            }
            $sentCounts[$bucket]++;

            // Parse quotes
            $quotes = [];
            if (!empty($article['quotes']) && is_array($article['quotes'])) {
                foreach ($article['quotes'] as $q) {
                    $kutipan    = trim($q['Kutipan']    ?? $q['kutipan']    ?? '');
                    $narasumber = trim($q['Narasumber'] ?? $q['narasumber'] ?? '');
                    if ($kutipan) {
                        $quotes[] = [
                            'text'   => substr($kutipan, 0, 200),
                            'source' => $narasumber,
                        ];
                    }
                }
            }

            $parsedArticles[] = [
                'title'     => substr(strip_tags($article['title']     ?? 'Untitled'), 0, 120),
                'publisher' => substr($article['publisher'] ?? $article['hostname'] ?? 'Unknown', 0, 40),
                'date'      => substr($article['date_created'] ?? '', 0, 10),
                'sentiment' => $bucket,
                'content'   => substr(strip_tags($article['content'] ?? ''), 0, 200),
                'quotes'    => $quotes,
                'url'       => $article['url'] ?? '',
            ];
        }

        // ── 3. Parse publishers ──
        $publishers = [];
        if (is_array($publishersRaw)) {
            $rank = 1;
            foreach ($publishersRaw as $domain => $count) {
                if (!is_string($domain)) continue;
                $publishers[] = [
                    'domain' => $domain,
                    'count'  => (int) $count,
                    'rank'   => $rank++,
                ];
                if ($rank > 20) break;
            }
        }

        // ── 4. Parse sentiment total ──
        $positive = 0; $negative = 0; $neutral = 0;
        if (isset($sentimentRaw['pos'], $sentimentRaw['neg'], $sentimentRaw['net'])) {
            $positive = (int) $sentimentRaw['pos'];
            $negative = (int) $sentimentRaw['neg'];
            $neutral  = (int) $sentimentRaw['net'];
        } elseif (isset($sentimentRaw['bymedia']['doc'])) {
            $d        = $sentimentRaw['bymedia']['doc'];
            $positive = (int) ($d['pos'] ?? 0);
            $negative = (int) ($d['neg'] ?? 0);
            $neutral  = (int) ($d['net'] ?? 0);
        }

        // Fallback ke hitungan dari articles kalau sentiment API kosong
        if ($positive === 0 && $negative === 0 && $neutral === 0) {
            $positive = $sentCounts['positive'];
            $negative = $sentCounts['negative'];
            $neutral  = $sentCounts['neutral'];
        }

        // ── 5. Parse word cloud — ambil top 30 ──
        $phrases = [];
        $wcRaw   = $wordCloudRaw['data']['phrases'] ?? $wordCloudRaw['phrases'] ?? [];
        arsort($wcRaw);
        $i = 0;
        foreach ($wcRaw as $word => $count) {
            $phrases[] = "{$word}({$count})";
            if (++$i >= 30) break;
        }

        // ── 6. Build dataset string untuk AI ──
        $total  = $positive + $negative + $neutral ?: 1;
        $pctPos = round($positive / $total * 100);
        $pctNeg = round($negative / $total * 100);
        $pctNeu = round($neutral  / $total * 100);

        $lines   = [];
        $lines[] = "=== DATA BERITA (ONLINE NEWS) PROJECT {$projectId} ===";
        $lines[] = "Periode: {$startDate} s/d {$endDate}";
        $lines[] = "Total Artikel: " . count($articles);
        $lines[] = "Sentimen: Positif {$pctPos}% ({$positive}) | Negatif {$pctNeg}% ({$negative}) | Netral {$pctNeu}% ({$neutral})";

        // Top Publishers
        if (!empty($publishers)) {
            $lines[] = "\n--- TOP PUBLISHERS ---";
            foreach (array_slice($publishers, 0, 15) as $i => $pub) {
                $lines[] = ($i + 1) . ". {$pub['domain']} ({$pub['count']} artikel)";
            }
        }

        // Word Cloud keywords
        if (!empty($phrases)) {
            $lines[] = "\n--- TOP KEYWORDS ---";
            $lines[] = implode(', ', $phrases);
        }

        // Separate articles by sentiment
        $negArticles = array_filter($parsedArticles, fn($a) => $a['sentiment'] === 'negative');
        $posArticles = array_filter($parsedArticles, fn($a) => $a['sentiment'] === 'positive');
        $neuArticles = array_filter($parsedArticles, fn($a) => $a['sentiment'] === 'neutral');

        // Prioritaskan negatif dulu karena biasanya lebih actionable
        $sample = array_values(array_merge(
            array_slice(array_values($negArticles), 0, 20),
            array_slice(array_values($posArticles), 0, 10),
            array_slice(array_values($neuArticles), 0,  5),
        ));

        $lines[] = "\n--- SAMPEL ARTIKEL (" . count($sample) . " dari " . count($parsedArticles) . ") ---";
        foreach ($sample as $i => $art) {
            $lines[] = "[" . ($i + 1) . "] \"{$art['title']}\" | {$art['publisher']} | {$art['date']} | {$art['sentiment']}";

            // Sertakan kutipan narasumber kalau ada
            foreach (array_slice($art['quotes'], 0, 2) as $q) {
                if ($q['text']) {
                    $src = $q['source'] ? " — {$q['source']}" : '';
                    $lines[] = "   → \"{$q['text']}\"{$src}";
                }
            }
        }

        $lines[] = "=== AKHIR DATASET ===";

        Log::info('News aiAnalysisData', [
            'project_id'      => $projectId,
            'total_articles'  => count($parsedArticles),
            'total_publishers'=> count($publishers),
            'total_keywords'  => count($phrases),
            'sentiment'       => compact('positive', 'negative', 'neutral'),
        ]);

        return response()->json([
            'success' => true,
            'data'    => [
                'dataset' => implode("\n", $lines),
                'summary' => [
                    'total_articles'   => count($parsedArticles),
                    'total_publishers' => count($publishers),
                    'total_keywords'   => count($phrases),
                    'sentiment'        => compact('positive', 'negative', 'neutral'),
                ],
            ],
        ]);

    } catch (\Exception $e) {
        Log::error('News aiAnalysisData error', ['error' => $e->getMessage()]);
        return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
    }
}
}