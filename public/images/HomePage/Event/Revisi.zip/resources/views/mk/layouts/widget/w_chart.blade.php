@extends('layouts.app')

@section('title', 'Widget Chart')

@section('main')
    <div class="pc-container">
        <div class="pc-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5 class="mb-0">Widget-active</h5>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <ul class="breadcrumb mb-0">
                                <li class="breadcrumb-item"><a href="/dashboard/index.html">Home</a></li>
                                <li class="breadcrumb-item"><a href="javascript: void(0)">Widget</a></li>
                                <li class="breadcrumb-item" aria-current="page">Widget-active</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->

            <div class="row">
                <!-- [ statistic chat ] start -->
                <div class="col-xl-4 col-md-12">
                    <div class="card card-command">
                        <div class="card-header">
                            <h5 class="d-flex align-items-center gap-2"><i
                                    class="card-icon ph ph-chat-circle f-18"></i>command</h5>
                        </div>
                        <div id="command-card-chart1"></div>
                        <div class="card-body">
                            <div class="comment-bar">
                                <h6 class="text-uppercase text-muted">COMMENTERS<span class="text-uppercase float-end">view
                                        all</span> </h6>
                                <div class="row align-items-center justify-content-center mt-4">
                                    <div class="col">
                                        <h6 class="mb-0"><img class="rounded-circle me-2 ms-2" style="width: 40px"
                                                src="../assets/images/user/avatar-2.svg"
                                                alt="activity-user text-uppercase" /><span
                                                class="d-block d-sm-inline-block m-t-10">Ida Jorgensen</span></h6>
                                    </div>
                                    <div class="col-auto text-end">
                                        <span class="float-end f-14">3 comments</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Sales</h5>
                        </div>
                        <div class="card-body">
                            <div id="chart-sale" class="chart-sale"> </div>
                            <div class="row text-center mt-3">
                                <div class="col-sm-12">
                                    <h3 class="f-w-300">84</h3>
                                    <span class="text-uppercase">12 Today</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                        </div>
                        <div class="card-body">
                            <div id="Stack-bar" class="Stackchart"> </div>
                        </div>
                    </div>
                </div>
                <!--[ statistic chat ] end -->

                <!-- [ visit-statistics,linechart chart ] start -->
                <div class="col-xl-8 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                        </div>
                        <div class="card-body">
                            <div id="line-area2" class="lineAreaDashboard"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-12">
                    <div class="card bg-brand-color-1 gradientcolor overflow-hidden">
                        <div class="card-header border-0">
                            <h5 class="text-white">Statistics</h5>
                        </div>
                        <div class="card-body pb-0">
                            <div class="p-2 text-center">
                                <a class="text-white text-uppercase f-w-400">Month</a>
                                <a class="btn btn-round bg-white text-uppercase mx-3 px-4 f-w-400">Week</a>
                                <a class="text-white text-uppercase f-w-400">Day</a>
                            </div>
                            <div class="my-3 text-center text-white">
                                <a href="#" class="text-white d-block mb-1">$78.89 <span class="ph ph-arrow-up"></span></a>
                                <span>Week2 +15.44</span>
                            </div>
                            <div id="Chartline" class="lineChart ChartShadow"></div>
                        </div>
                    </div>
                </div>
                <!-- [ visit-statistics,line chart end ]-->

                <!-- [ new statistics chart ] start -->
                <div class="col-xl-4 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>News Statistics</h5>
                        </div>
                        <div class="card-body ps-0 pe-0 pb-2">
                            <div id="bar-chart" class="ChartShadow BarChart"></div>
                        </div>
                        <div class="card-body border-top">
                            <div class="row">
                                <div class="col text-center">
                                    <span class="bg-brand-color-1 d-block rounded-circle mx-auto mb-2"
                                        style="width: 10px; height: 10px"></span>
                                    <h6 class="mb-2">53</h6>
                                    <h6 class="mt-2 mb-0">Sport</h6>
                                </div>
                                <div class="col text-center">
                                    <span class="bg-brand-color-2 d-block rounded-circle mx-auto mb-2"
                                        style="width: 10px; height: 10px"></span>
                                    <h6 class="mb-2">13</h6>
                                    <h6 class="mt-2 mb-0">Music</h6>
                                </div>
                                <div class="col text-center">
                                    <span class="bg-primary d-block rounded-circle mx-auto mb-2"
                                        style="width: 10px; height: 10px"></span>
                                    <h6 class="mb-2">30</h6>
                                    <h6 class="mt-2 mb-0">Travel</h6>
                                </div>
                                <div class="col text-center">
                                    <span class="bg-danger d-block rounded-circle mx-auto mb-2"
                                        style="width: 10px; height: 10px"></span>
                                    <h6 class="mb-2">4</h6>
                                    <h6 class="mt-2 mb-0">News</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-8 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                        </div>
                        <div class="card-body">
                            <div id="line-chart1" class="ChartShadow"></div>
                        </div>
                    </div>
                </div>
                <!-- [ new statistics chart ] end -->

                <!-- [ statistics year chart ] start -->
                <div class="col-xl-8 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                        </div>
                        <div class="card-body">
                            <div id="line-chart2" class="lineChart2 ChartShadow"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card bg-primary">
                        <div class="card-header border-0">
                            <h5 class="text-white">Earnings</h5>
                        </div>
                        <div class="card-body" style="padding: 0 25px">
                            <div class="earning-text mb-1">
                                <h3 class="mb-2 text-white f-w-300">$4295.36 <i class="ph ph-arrow-up teal accent-3"></i>
                                </h3>
                                <span class="text-uppercase text-white d-block">Total Earnings</span>
                            </div>
                            <div id="Widget-line-chart" class="WidgetlineChart2 ChartShadow"></div>
                        </div>
                    </div>
                </div>
                <!-- [ statistics year chart ] end -->

                <!-- [ earning chart ] start -->
                <div class="col-xl-4 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Earnings</h5>
                            <span class="d-block pt-2">Mon 15 - Sun 21</span>
                        </div>
                        <div class="card-body">
                            <div class="earning-price mb-1">
                                <h3 class="m-0 f-w-300">$894.39</h3>
                            </div>
                            <div id="Widget-line-chart1" class="WidgetlineChart"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Reply</h5>
                        </div>
                        <div class="card-body">
                            <div class="reply-price">
                                <h3>2.43 h</h3>
                                <span class="text-uppercase">average time for first reply</span>
                            </div>
                            <div id="bar-chart1" class="ChartShadow BarChart barChart1"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                        </div>
                        <div class="card-body">
                            <div id="chart-percent" class="chart-percent"></div>
                            <div class="row mb-3 mt-4">
                                <div class="col">
                                    <span class="mb-1 text-muted d-block">23%</span>
                                    <div class="progress" style="height: 5px">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 23%"
                                            aria-valuenow="23" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col">
                                    <span class="mb-1 text-muted d-block">14%</span>
                                    <div class="progress" style="height: 5px">
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 14%"
                                            aria-valuenow="14" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col">
                                    <span class="mb-1 text-muted d-block">35%</span>
                                    <div class="progress" style="height: 5px">
                                        <div class="progress-bar bg-purple-500" role="progressbar" style="width: 35%"
                                            aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col">
                                    <span class="mb-1 text-muted d-block">28%</span>
                                    <div class="progress" style="height: 5px">
                                        <div class="progress-bar bg-primary" role="progressbar" style="width: 28%"
                                            aria-valuenow="28" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- [ earning chart ] end -->

                <!-- [ statistics multi chart ] start -->
                <div class="col-xl-8 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                        </div>
                        <div class="card-body pb-0">
                            <div id="bar-chart2" class="bar-chart2"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Devices</h5>
                        </div>
                        <div class="card-body">
                            <div id="device-chart" class="device-chart"></div>
                            <div class="row">
                                <div class="col-sm-12 pt-3 pb-3 border-top">
                                    <span class="d-inline-flex align-items-center gap-1"><i
                                            class="ph ph-circle text-success"></i><span>Desktop</span></span>
                                    <span class="float-end">41.6 %</span>
                                </div>

                                <div class="col-sm-12 pt-3 pb-3 border-top">
                                    <span class="d-inline-flex align-items-center gap-1"><i
                                            class="ph ph-circle text-primary"></i><span>Mobile</span></span>
                                    <span class="float-end">32.5 %</span>
                                </div>

                                <div class="col-sm-12 pt-3 border-top">
                                    <span class="d-inline-flex align-items-center gap-1"><i
                                            class="ph ph-circle text-info"></i><span>Tablet</span></span>
                                    <span class="float-end">25.9 %</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- [ statistics multi chart ] end -->

                <!-- [ yearly summary chart ] start -->
                <div class="col-xl-4 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5><img class="rounded-circle m-r-10" style="width: 40px"
                                    src="../assets/images/user/avatar-3.svg" alt="activity-user" />
                                Jonas Nielsen
                            </h5>
                        </div>
                        <div class="card-body">
                            <h3 class="f-w-300">$359,234</h3>
                            <span class="d-block pt-1 pb-3">TOTAL SAVINGS</span>
                            <div id="chart-percent1" class="chart-percent1"></div>
                            <div class="client-name">
                                <div class="row">
                                    <div class="col-sm-12 pt-2 pb-2">
                                        <span class="d-inline-flex align-items-center gap-1"><i
                                                class="ph ph-circle text-success"></i><span>Main wallet</span></span>
                                        <span class="float-end text-muted">$194.42</span>
                                    </div>
                                    <div class="col-sm-12 pt-2 pb-2">
                                        <span class="d-inline-flex align-items-center gap-1"><i
                                                class="ph ph-circle text-primary"></i><span>Travel</span></span>
                                        <span class="float-end text-muted">$86.48</span>
                                    </div>
                                    <div class="col-sm-12 pt-2">
                                        <span class="d-inline-flex align-items-center gap-1"><i
                                                class="ph ph-circle text-info"></i><span>Food & Drink</span></span>
                                        <span class="float-end text-muted">$23.27</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-8 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Yearly Summary</h5>
                        </div>
                        <div class="card-body">
                            <div class="row pb-3">
                                <div class="col-md-4 col-6 text-center m-b-15">
                                    <h3 class="f-w-300">$2356.4</h3>
                                    <span>Invoiced</span>
                                </div>
                                <div class="col-md-4 col-6 text-center m-b-15">
                                    <h3 class="f-w-300">$1935.6</h3>
                                    <span>Profit</span>
                                </div>
                                <div class="col-md-4 col-12 text-center m-b-15">
                                    <h3 class="f-w-300">$468.9</h3>
                                    <span>Expenses</span>
                                </div>
                            </div>
                            <div id="bar-chart3" class="bar-chart3"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-8 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Last 3 Days</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 col-6 text-center m-b-15">
                                    <h3 class="f-w-300">$32,42</h3>
                                    <span class="text-end">Mon <strong>+5,93</strong></span>
                                </div>

                                <div class="col-md-4 col-6 text-center m-b-15">
                                    <h3 class="f-w-300">$28,36</h3>
                                    <span class="text-end">Tue <strong>-4,24</strong></span>
                                </div>

                                <div class="col-md-4 col-12 text-center m-b-15">
                                    <h3 class="f-w-300">$59,48</h3>
                                    <span class="text-end">Wed <strong>+12,25</strong></span>
                                </div>
                            </div>
                        </div>
                        <div id="processed-bar"></div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                        </div>
                        <div class="card-body">
                            <div id="chart-statistics" class="chart-statistics"> </div>
                            <div class="row">
                                <div class="col-sm-12 pt-2 pb-2">
                                    <span class="d-inline-flex align-items-center gap-1"><i
                                            class="ph ph-circle text-success"></i><span>page Views</span></span>
                                    <span class="float-end">15.5 %</span>
                                </div>
                                <div class="col-sm-12 pt-2 pb-2">
                                    <span class="d-inline-flex align-items-center gap-1"><i
                                            class="ph ph-circle text-primary"></i><span>page Clicks</span></span>
                                    <span class="float-end">23.5 %</span>
                                </div>
                                <div class="col-sm-12 pt-2">
                                    <span class="d-inline-flex align-items-center gap-1"><i
                                            class="ph ph-circle text-info"></i><span>page Likes</span></span>
                                    <span class="float-end">36.3 %</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- [ yearly summary chart end ] -->

                <!-- [ Activity summary chart ] start -->
                <div class="col-md-6 col-xl-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Activity</h5>
                        </div>
                        <div class="card-body">
                            <div id="chart-activity" class="chart-activity"> </div>
                            <div class="row text-center">
                                <div class="col-6">
                                    <h6 class="text-uppercase d-block mb-2">max</h6>
                                    <h3 class="f-w-300">9.376</h3>
                                    <h6>Steps</h6>
                                </div>
                                <div class="col-6">
                                    <h6 class="text-uppercase d-block mb-2">min</h6>
                                    <h3 class="font-weight-light">237</h3>
                                    <h6>Steps</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-xl-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                        </div>
                        <div class="card-body">
                            <h3 class="f-w-300">$894.39</h3>
                        </div>
                        <div id="Earnings-chart"></div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                            <span class="d-block pt-2">Last 6 Months</span>
                        </div>
                        <div class="card-body">
                            <div id="sales-render"></div>
                        </div>
                    </div>
                </div>
                <!-- [ Activity summary chart ] end -->

                <!-- [ Web Statistics chart ] start -->
                <div class="col-xl-4 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Web Statistics</h5>
                        </div>
                        <div class="card-body">
                            <div id="webchart"></div>
                            <div class="row">
                                <div class="col-sm-12 pt-3 pb-3 mt-3 border-top">
                                    <span class="me-3">Sales</span>
                                    <span class="float-end">563 / 735</span>
                                </div>

                                <div class="col-sm-12 pt-3 pb-3 border-top">
                                    <span class="me-3">Clicks</span>
                                    <span class="float-end">76898 / 95442</span>
                                </div>
                                <div class="col-sm-12 pt-3 pb-3 border-top">
                                    <span class="me-3">Views</span>
                                    <span class="float-end">3682 / 4235</span>
                                </div>
                                <div class="col-sm-12 pt-3 border-top">
                                    <span class="me-3">Visits</span>
                                    <span class="float-end">2348 / 3749</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-8 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Statistics</h5>
                        </div>
                        <div class="card-body">
                            <div id="Statistics-line" class="ChartShadow"></div>
                        </div>
                    </div>
                </div>
                <!-- [  Web Statistics chart ] end -->

                <!-- [ Transactions chart ] start -->
                <div class="col-md-6 col-xl-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Transactions</h5>
                            <span class="d-block pt-2">Jun 23 - Jul 23</span>
                        </div>
                        <div class="card-body">
                            <div class="row align-items-center justify-content-center">
                                <div class="col-6">
                                    <h3 class="f-w-300 mb-0 float-start">$59,48</h3>
                                </div>
                                <div class="col-6">
                                    <div id="transactions" class="float-end"
                                        style="height: 90px; width: 80px; margin: 0 auto"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Transactions</h5>
                            <span class="d-block pt-2">June - July</span>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div id="transactions1" style="height: 45px; width: 80px; margin: 0 auto"></div>
                                    <h3 class="f-w-300 pt-3 mb-0 text-center">$80,48</h3>
                                </div>

                                <div class="col-6">
                                    <div id="transactions2" style="height: 45px; width: 80px; margin: 0 auto"></div>
                                    <h3 class="f-w-300 pt-3 mb-0 text-center">$40,27</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-xl-4">
                    <div class="card">
                        <div class="card-header">
                            <h5>Transactions</h5>
                            <span class="d-block pt-2">Jun 23 - Jul 23</span>
                        </div>
                        <div class="card-body">
                            <div class="row align-items-center justify-content-center">
                                <div class="col-6">
                                    <div id="transactions3" class="float-start"
                                        style="height: 90px; width: 80px; margin: 0 auto"></div>
                                </div>
                                <div class="col-6">
                                    <h3 class="f-w-300 mb-0 float-end">$59,48</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- [ Transactions chart ] end -->

                <!-- [ star section ] start -->
                <div class="col-md-6 col-xl-4">
                    <div class="card bg-brand-color-2">
                        <div class="card-header border-0">
                            <h5 class="text-white">Stats</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 col-6 text-center m-b-10">
                                    <h3 class="text-white f-w-300">932</h3>
                                    <span class="d-block text-white">This Month</span>
                                </div>
                                <div class="col-md-4 col-6 text-center m-b-10">
                                    <h3 class="text-white f-w-300">85</h3>
                                    <span class="d-block text-white">This Week</span>
                                </div>
                                <div class="col-md-4 col-12 text-center m-b-10">
                                    <h3 class="text-white f-w-300">26</h3>
                                    <span class="d-block text-white">Today</span>
                                </div>
                            </div>
                        </div>
                        <div id="sitevisite-chart" class="last-week-sales"></div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="card bg-primary">
                        <div class="card-header border-0">
                            <h5 class="text-white">Statistics</h5>
                        </div>
                        <div class="card-body">
                            <div id="Statistics-sale" class="last-week-sales"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-sm-12">
                    <div class="card">
                        <div class="card-body user-chart">
                            <div class="row align-items-center justify-content-center">
                                <div class="col-auto">
                                    <i class="ph ph-chart-line-up f-30"></i>
                                </div>
                                <div class="col text-center">
                                    <img class="img-fluid rounded-circle" src="../assets/images/user/avatar-1.svg"
                                        alt="dashboard-user" />
                                </div>
                                <div class="col-auto">
                                    <i class="ph ph-envelope-simple f-30"></i>
                                </div>
                            </div>
                            <h5 class="m-t-30 text-center">Alma Christensen</h5>
                            <span class="text-center d-block">UX Designer</span>
                            <div class="row m-t-40">
                                <div class="col-6">
                                    <div id="power-card-chart" class="ChartShadow"></div>
                                </div>
                                <div class="col-6">
                                    <h3 class="f-w-300"><i
                                            class="ti ti-caret-up-filled text-success f-22 m-r-10 m-l-10"></i>13 % </h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- [ star section ] end -->

                <!-- [ worldLow section ] start -->
                <div class="col-xl-8 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Users from United States</h5>
                        </div>
                        <div class="card-body">
                            <div id="world-low" class="set-map" style="height: 350px"> </div>
                        </div>
                    </div>
                </div>
                <!-- [ worldLow section ] end -->

                <!-- [ sad-chart ] start -->
                <div class="col-xl-4 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Reviews</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-6 text-center m-b-20">
                                    <h6 class="pb-4 d-block">NEGATIVE</h6>
                                    <div id="sadball"></div>
                                    <h3 class="font-weight-light mt-2">26%</h3>
                                    <span class="b-block pt-2">57 Reviews</span>
                                </div>
                                <div class="col-sm-6 text-center m-b-20">
                                    <h6 class="pb-4 d-block">POSITIVE</h6>
                                    <div id="happyball"></div>
                                    <h3 class="font-weight-light mt-2">74%</h3>
                                    <span class="b-block pt-2">567 Reviews</span>
                                </div>
                                <div class="col-sm-12">
                                    <button class="btn btn-primary shadow-2 text-uppercase w-100 mt-3 me-0"
                                        type="button">view all reviews</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- [ sad-chart ] end -->

                <!-- [ call-chart ] start -->
                <div class="col-xl-4 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Phone Calls</h5>
                        </div>
                        <div id="call-chart"></div>
                    </div>
                </div>
                <!-- [ call-chart ] end -->

                <!-- [ progress-bar ] start -->
                <div class="col-xl-4 col-sm-12">
                    <div class="card progress-gender">
                        <div class="card-header">
                            <h5>Gender</h5>
                        </div>
                        <div class="card-body">
                            <h6 class="m-b-10">Female <span class="float-end">Male</span></h6>
                            <div class="progress">
                                <div class="progress-bar bg-brand-color-2" role="progressbar"
                                    style="width: 30%; height: 10px" aria-valuenow="30" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                                <div class="progress-bar bg-brand-color-1" role="progressbar"
                                    style="width: 30%; height: 10px" aria-valuenow="30" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                            </div>
                            <h5 class="f-w-300 m-t-20 text-muted">62%<span class="float-end">28%</span> </h5>
                            <h6 class="m-b-10 m-t-20">Female <span class="float-end">Male</span></h6>
                            <div class="progress">
                                <div class="progress-bar bg-brand-color-2" role="progressbar"
                                    style="width: 40%; height: 10px" aria-valuenow="40" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                                <div class="progress-bar bg-brand-color-1" role="progressbar"
                                    style="width: 30%; height: 10px" aria-valuenow="30" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                            </div>
                            <h5 class="f-w-300 m-t-20 text-muted">60%<span class="float-end">50%</span> </h5>
                            <h6 class="m-b-10 m-t-20">Female <span class="float-end">Male</span></h6>
                            <div class="progress">
                                <div class="progress-bar bg-brand-color-2" role="progressbar"
                                    style="width: 50%; height: 10px" aria-valuenow="50" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                                <div class="progress-bar bg-brand-color-1" role="progressbar"
                                    style="width: 52%; height: 10px" aria-valuenow="50" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                            </div>
                            <h5 class="f-w-300 m-t-20 text-muted">50%<span class="float-end">50%</span> </h5>
                        </div>
                    </div>
                </div>
                <!-- [ progress-bar ] end -->

                <!-- [ age -section] start -->
                <div class="col-xl-4 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Age</h5>
                        </div>
                        <div class="card-body">
                            <div id="Stack-age" class="Stackchart" style="height: 250px"></div>
                        </div>
                    </div>
                </div>
                <!-- [ age -section] end -->
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
@endsection